# CutProof publication drafts

Source: Whisper-generated captions (review required)
Transcript SHA-256: 90b389ee05dd147a1b91e7ccffb3759bc42bc336900f5415caf870319629bd4f

These are verbatim source excerpts, not independently verified claims. Review every cut and its surrounding source before publication.

## clip-01: This is a fictional product review.

Source range: 0:00 to 0:11
Review: pending

> This is a fictional product review. The battery does not last 12 hours. It lasts about 7 hours during video calls. Please keep that qualification in the final clip.

Context checks: Contains numbers. Confirm their units and qualifications against the original source.

Topics: hours, 12, fictional, product

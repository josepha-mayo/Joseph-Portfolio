# CutProof publication drafts

Source: Synthetic missing-word test (deliberately incorrect captions)
Transcript SHA-256: 610cd14f145b5ac8abe23da44b7a1c41d50a986788e75d887e85b70097a5165d

These are verbatim source excerpts, not independently verified claims. Review every cut and its surrounding source before publication.

## clip-01: The temperature is -5 degrees.

Source range: 0:00 to 0:04
Review: reviewed

> The temperature is -5 degrees.

Context checks: Contains numbers. Confirm their units and qualifications against the original source.

Topics: 

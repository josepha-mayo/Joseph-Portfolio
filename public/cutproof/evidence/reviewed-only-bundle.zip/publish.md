# CutProof publication drafts

Source: cutproof-original-demo.srt
Transcript SHA-256: 07fd3b2e25aed1d41dedf6d610a4a2bceb3823bed339f87b7eabb078a34beb0f

These are verbatim source excerpts, not independently verified claims. Review every cut and its surrounding source before publication.

## clip-01: A better editing workflow starts with the source, rather than a pile of generated claims.

Source range: 0:47 to 1:20
Review: reviewed

> A better editing workflow starts with the source, rather than a pile of generated claims. First choose complete caption ranges. Keep every word inside the selected range in its original order. Then inspect the sentence before and the sentence after the cut. Look for explanations and qualifications. If the next sentence changes the claim, include it or choose a different clip. Captions should use the new clip timeline. A clip starting two minutes into a recording still needs captions near zero.

Context checks: Contains numbers. Confirm their units and qualifications against the original source.

Topics: sentence, clip, choose, captions

CUTPROOF EDIT BUNDLE

Captions are relative to each clip. The manifest retains absolute source times.
Video is not embedded. Use the original video that matches the transcript.

Native render, with Python 3.10+ and FFmpeg/ffprobe installed:
  python render.py --bundle . --media "your-source.mp4" --out rendered

The renderer validates transcript provenance and source duration before encoding.
A matching transcript fingerprint is not proof that the transcript matches the audio.
No video has been uploaded or published by exporting this bundle.

EDITOR HANDOFF
review.html is a script-free context review page. losslesscut.llc and segments.csv contain exact requested segment times; relink the original media. Actual LosslessCut desktop import and keyframe behavior have not been tested. project.cutproof.json restores source ranges in CutProof with reviews reset.

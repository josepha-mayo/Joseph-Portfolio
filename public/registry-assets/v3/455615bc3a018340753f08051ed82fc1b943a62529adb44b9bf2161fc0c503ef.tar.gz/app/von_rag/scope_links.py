"""Selected literal relationships for product-to-asset firmware answers.

This is an opt-in proof, not entity inference: missing or contradictory links
retain the normal rejection. No answer, citation, or source text is rewritten.
"""
from __future__ import annotations

import re
from .retrieval import identifiers
from .conflicts import _property, _scalar

_PRIMARY = {'product', 'model', 'device'}
_SCOPE = _PRIMARY | {'partnumber', 'partno', 'pn', 'sku', 'asset', 'component',
                    'serialnumber', 'item', 'assembly', 'module'}
_TICKET = {'ticket', 'ticketid', 'issue', 'issueid', 'bug', 'bugid',
           'case', 'caseid', 'defect', 'defectid'}
_SECONDARY_TYPES = {
    'partnumber': 'part', 'partno': 'part', 'pn': 'part',
    'sku': 'sku', 'asset': 'asset', 'component': 'component',
    'serialnumber': 'serial', 'item': 'item', 'assembly': 'assembly',
    'module': 'module',
}
_COLON = re.compile(r'^[ \t]*([A-Za-z][A-Za-z _]{0,50}):[ \t]*(.+?)[ \t]*$', re.M)
_EQUALS = re.compile(r'(?<!\w)([A-Za-z][A-Za-z0-9_]*)=(?:"([^"\r\n]*)"|([^\s]+))')


def _literal_fields(record):
    text = record.get('text', '')
    pairs = [(m[1], m[2]) for m in _COLON.finditer(text)]
    if record.get('kind') == 'log' or record.get('source', '').endswith('.log'):
        pairs.extend((m[1], m[2] if m[2] is not None else m[3])
                     for m in _EQUALS.finditer(text))
    fields = {}
    for name, value in pairs:
        key = re.sub(r'[^a-z]', '', name.casefold())
        if key in fields:
            return None  # Repeated literal keys do not establish one record.
        fields[key] = value.strip()
    return fields


def _typed_ids(fields):
    result = {}
    for key, value in fields.items():
        if key not in _SCOPE | _TICKET:
            continue
        ids = identifiers(value)
        if len(ids) != 1:
            return None
        result[key] = ids
    return result


def _ids(fields, keys):
    return set().union(*(value for key, value in fields.items() if key in keys))


def _secondary_ids(typed):
    """Canonical typed identifiers; contradictory aliases are ambiguous."""
    result = {}
    for key, ids in typed.items():
        kind = _SECONDARY_TYPES.get(key)
        if kind is None:
            continue
        if kind in result and result[kind] != ids:
            return None
        result[kind] = ids
    return result


def _compatible_identity(left, right):
    """At least one shared type must match and no shared type may disagree.

    Distinct additional qualifiers refine the same shared identity. Equal
    identifier spelling under unrelated types does not establish a relation.
    """
    common = left.keys() & right.keys()
    return bool(common) and all(left[kind] == right[kind] for kind in common)


def _active(record, fields):
    # Do not infer authority from a draft or ambiguous status in this opt-in path.
    return not record.get('retired') and fields.get('status', 'current').casefold() == 'current'


def _has_conflicting_value(records, value, fields, scope_ids, ticket, query):
    """A second visible current value for the same typed join cannot be ignored."""
    _, aliases = _property(query)
    values = {_scalar(v, 'firmware') for k, v in fields.items() if k in aliases}
    wanted = identifiers(query)
    secondary = _secondary_ids(_typed_ids(fields))
    if len(values) != 1 or not secondary:
        return True
    for other in records:
        if other is value or other.get('retired'):
            continue
        other_fields = _literal_fields(other)
        if other_fields is None or not _active(other, other_fields):
            continue
        typed = _typed_ids(other_fields)
        if typed is None:
            continue
        primary = _ids(typed, _PRIMARY)
        other_secondary = _secondary_ids(typed)
        if not other_secondary or (primary and primary != wanted):
            continue
        if (_compatible_identity(secondary, other_secondary)
                and _ids(typed, _TICKET) == ticket):
            observed = {_scalar(v, 'firmware') for k, v in other_fields.items() if k in aliases}
            if observed and observed != values:
                return True
    return False


def selected_firmware_scope_link(records, selected, value_index, query, scope_ids,
                                 *, sibling_records=()):
    """Require a selected root with exact primary product, secondary IDs and ticket.

    Shared tickets alone, prose mentions, same-file association, foreign primary
    products, and conflicting visible values cannot justify a secondary scope.
    All ordinary property, condition, quotation and citation checks still apply.
    """
    wanted = identifiers(query)
    if len(wanted) != 1 or _property(query)[0] != 'firmware':
        return False
    value = records[value_index]
    fields = _literal_fields(value)
    if fields is None or not _active(value, fields):
        return False
    typed = _typed_ids(fields)
    if typed is None or not _ids(typed, _PRIMARY) <= wanted:
        return False
    if scope_ids != _ids(typed, _SCOPE):
        return False
    secondary = _secondary_ids(typed)
    if not secondary:
        return False
    ticket = _ids(typed, _TICKET)
    if len(ticket) != 1:
        return False
    if _has_conflicting_value(list(records) + list(sibling_records),
                              value, fields, scope_ids, ticket, query):
        return False
    for index in selected:
        if index == value_index:
            continue
        root = records[index]
        root_fields = _literal_fields(root)
        if root_fields is None or not _active(root, root_fields):
            continue
        root_typed = _typed_ids(root_fields)
        if root_typed is None:
            continue
        root_secondary = _secondary_ids(root_typed)
        if (root_secondary and _ids(root_typed, _PRIMARY) == wanted
                and all(root_secondary.get(kind) == ids
                        for kind, ids in secondary.items())
                and _ids(root_typed, _TICKET) == ticket):
            return True
    return False
